<?php

add_action('init', 'create_gmaps_vc');
add_shortcode( 'wwp_vc_gmaps', 'wwp_vc_gmaps');

function create_gmaps_vc()
{
    if(!function_exists('vc_map'))
    {
        return;
    }

    vc_map(array(
        "name" => 'GMAPS for VC',
        'as_parent' => array( 'only' => 'wwp_vc_gmaps_marker' ),
        "base" => "wwp_vc_gmaps",
        'content_element' => true,
        'icon' => 'map',
        'show_settings_on_create' => true,
        "js_view" => 'VcColumnView',
        "description" => __("Display Google Maps to indicate your location."),
        "category" => wwp_vc_gmaps_name,
        "params" => array(

            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Map Name"),
                "param_name" => "map_name",
                "admin_label" => true,
                "value" => "",
                "group" => "Styling",
                "description" => "Title for a styled map (default: Custom Map)"
            ),

            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Auto Zoom"),
                "param_name" => "disable_auto_zoom",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Styling",
                "std" => "true",
                "description" => "Auto center map based on marker(s)"
            ),

            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Zoom"),
                "param_name" => "zoom",
                "admin_label" => false,
                "value" => "17",
                "group" => "Styling",
                "dependency" => array('element'=>'disable_auto_zoom','value'=>"false"),
                "description" => "Zoom level"
            ),

            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Width"),
                "param_name" => "width",
                "admin_label" => false,
                "value" => "100",
                "group" => "Styling",
                'edit_field_class' => 'vc_col-sm-6 vc_column'
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Width Type"),
                "param_name" => "width_type",
                "admin_label" => false,
                "value" => array( __("Pixels") => "px", __("Percentage") => "%"),
                "group" => "Styling",
                'edit_field_class' => 'vc_col-sm-6 vc_column',
                "std" => "%"
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Height"),
                "param_name" => "height",
                "admin_label" => false,
                "value" => "300",
                "group" => "Styling",
                'edit_field_class' => 'vc_col-sm-6 vc_column'
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Height Type"),
                "param_name" => "height_type",
                "admin_label" => false,
                "value" => array( __("Pixels") => "px", __("Percentage") => "%"),
                "group" => "Styling",
                'edit_field_class' => 'vc_col-sm-6 vc_column',
                "std" => "px"
            ),

            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Custom Map Style"),
                "param_name" => "custom_map_style",
                "admin_label" => false,
                "value" => array( __("Default") => "default", __("Custom") => "custom", __("Apple Maps") => "apple_maps",  __("Light Gray") => "light_gray", __("Dark") => "dark", __("Neutral Blue") => "neutral_blue", __("Orange Ocean") => "orange_ocean", __("Magenta") => "magenta", __("Flat Map") => "flat_map", __("Winter") => "winter"),
                "group" => "Styling",
                "std" => 0,
                "description" => "Apply predefined or custom styles to the map"
            ),

            array(
                "type" => "textarea_raw_html",
                "class" => "",
                "heading" => __("Custom Map Style"),
                "description" => 'Take a look on <a href="https://snazzymaps.com/" target="_blank">Snazzy Maps</a>',
                "param_name" => "styles",
                "admin_label" => false,
                "value" => "",
                "group" => "Styling",
                "dependency" => array('element'=>'custom_map_style','value'=>"custom"),
            ),

            array(
                "type" => "dropdown",
                "heading" => "Marker Clustering",
                "param_name" => "marker_clustering",
                "admin_label" => false,
                "value" => array( "No" => "no", "Yes" => "yes"),
                "std" => "no",
                "description" => "Option to enable or disable marker clustering",
                "group" => "Styling",
            ),

            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Disable All Map Controls"),
                "param_name" => "disable_map_controls",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Controls",
                "std" => "false",
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Map Type"),
                "param_name" => "map_type_control",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Controls",
                "dependency" => array('element'=>'disable_map_controls','value'=>"false"),
            ),
            array(
                "type" => "checkbox",
                "class" => "",
                "heading" => __("Map Type Options"),
                "param_name" => "map_type_control_options",
                "admin_label" => false,
                "value" => array(
                    'Roadmap' => 'ROADMAP',
                    'Terrain' => 'TERRAIN',
                    'Satellite' => 'SATELLITE',
                    'Hybrid' => 'HYBRID'
                ),
                "group" => "Controls",
                "dependency" => array('element'=>'map_type_control','value'=>"true"),
                "std" => "ROADMAP"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Map Type Position"),
                "param_name" => "map_type_control_position",
                "admin_label" => false,
                "value" => array(
                    'Top Left' => 'TOP_LEFT',
                    'Top Center' => 'TOP_CENTER',
                    'Top Right' => 'TOP_RIGHT',
                    'Bottom Left' => 'BOTTOM_LEFT',
                    'Bottom Right' => 'BOTTOM_RIGHT',
                    'Left Top' => 'LEFT_TOP',
                    'Left Center' => 'LEFT_CENTER',
                    'Left Bottom' => 'LEFT_BOTTOM',
                    'Right Top' => 'RIGHT_TOP',
                    'Right Center' => 'RIGHT_CENTER',
                    'Right Bottom' => 'RIGHT_BOTTOM',
                ),
                "group" => "Controls",
                "dependency" => array('element'=>'map_type_control','value'=>"true"),
                "std" => "LEFT_TOP"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Streetview"),
                "param_name" => "streetview_control",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Controls",
                "std" => "false",
                "dependency" => array('element'=>'disable_map_controls','value'=>"false"),
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Streetview Position"),
                "param_name" => "streetview_control_position",
                "admin_label" => false,
                "value" => array(
                    'Top Left' => 'TOP_LEFT',
                    'Top Center' => 'TOP_CENTER',
                    'Top Right' => 'TOP_RIGHT',
                    'Bottom Left' => 'BOTTOM_LEFT',
                    'Bottom Right' => 'BOTTOM_RIGHT',
                    'Left Top' => 'LEFT_TOP',
                    'Left Center' => 'LEFT_CENTER',
                    'Left Bottom' => 'LEFT_BOTTOM',
                    'Right Top' => 'RIGHT_TOP',
                    'Right Center' => 'RIGHT_CENTER',
                    'Right Bottom' => 'RIGHT_BOTTOM',
                ),
                "group" => "Controls",
                "dependency" => array('element'=>'streetview_control','value'=>"true"),
                "std" => "RIGHT_BOTTOM"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Zoom"),
                "param_name" => "zoom_control",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Controls",
                "dependency" => array('element'=>'disable_map_controls','value'=>"false"),
                "std" => "true"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Zoom Position"),
                "param_name" => "zoom_control_position",
                "admin_label" => false,
                "value" => array(
                    'Top Left' => 'TOP_LEFT',
                    'Top Center' => 'TOP_CENTER',
                    'Top Right' => 'TOP_RIGHT',
                    'Bottom Left' => 'BOTTOM_LEFT',
                    'Bottom Right' => 'BOTTOM_RIGHT',
                    'Left Top' => 'LEFT_TOP',
                    'Left Center' => 'LEFT_CENTER',
                    'Left Bottom' => 'LEFT_BOTTOM',
                    'Right Top' => 'RIGHT_TOP',
                    'Right Center' => 'RIGHT_CENTER',
                    'Right Bottom' => 'RIGHT_BOTTOM',
                ),
                "group" => "Controls",
                "dependency" => array('element'=>'zoom_control','value'=>"true"),
                "std" => "RIGHT_BOTTOM"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Fullscreen"),
                "param_name" => "fullscreen_control",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Controls",
                "std" => "false",
                "dependency" => array('element'=>'disable_map_controls','value'=>"false"),
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Dragging"),
                "param_name" => "dragging_control",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Controls",
                "dependency" => array('element'=>'disable_map_controls','value'=>"false"),
                "std" => "true"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Dragging Position"),
                "param_name" => "dragging_control_position",
                "admin_label" => false,
                "value" => array(
                    'Top Left' => 'TOP_LEFT',
                    'Top Center' => 'TOP_CENTER',
                    'Top Right' => 'TOP_RIGHT',
                    'Bottom Left' => 'BOTTOM_LEFT',
                    'Bottom Right' => 'BOTTOM_RIGHT',
                    'Left Top' => 'LEFT_TOP',
                    'Left Center' => 'LEFT_CENTER',
                    'Left Bottom' => 'LEFT_BOTTOM',
                    'Right Top' => 'RIGHT_TOP',
                    'Right Center' => 'RIGHT_CENTER',
                    'Right Bottom' => 'RIGHT_BOTTOM',
                ),
                "group" => "Controls",
                "dependency" => array('element'=>'dragging_control','value'=>"true"),
                "std" => "LEFT_CENTER"
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Traffic"),
                "param_name" => "traffic_layer",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Layers",
                "std" => "false",
                "description" => "Adds real-time traffic information (where supported)."
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Transit"),
                "param_name" => "transit_layer",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Layers",
                "std" => "false",
                "description" => "Adds a layer of transit paths, showing major transit lines as thick, colored lines."
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Bicycling"),
                "param_name" => "bicycling_layer",
                "admin_label" => false,
                "value" => array( __("Yes") => "true", __("No") => "false"),
                "group" => "Layers",
                "std" => "false",
                "description" => 'Adds a layer of bike paths, suggested bike routes and other overlays specific to bicycling usage.'
            ),

            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Dragging on Mobile"),
                "param_name" => "dragging_mobile",
                "value" => array( __("Enable") => "true", __("Disable") => "false"),
                "group" => "Dragging"
            ),

            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Dragging on Desktop"),
                "param_name" => "dragging_desktop",
                "value" => array( __("Enable") => "true", __("Disable") => "false"),
                "group" => "Dragging"
            )
        )
    ));
}

function wwp_vc_gmaps($atts, $content = null)
{
    global $WWP_GMAPS_SHORTCODE;
    $WWP_GMAPS_SHORTCODE['markers'] = array();

    $width = $add_dragging_control = $add_transit_layer = $add_traffic_layer = $add_bicycling_layer = $height = $lat = $lng = $add_map_height = $add_map_width = $add_map_width = $add_map_styling = $add_map_pin = $add_icon = $marker_description = '';

    extract(shortcode_atts(array(
        "fullscreen_control" => "false",
        "streetview_control" => "false",
        "streetview_control_position" => 'RIGHT_BOTTOM',
        "zoom_control" => "true",
        "zoom_control_position" => 'RIGHT_BOTTOM',
        "map_type_control" => "true",
        "map_type_control_position" => 'TOP_LEFT',
        "map_type_control_options" => 'ROADMAP',
        "dragging_control" => "true",
        "dragging_control_position" => "LEFT_CENTER",
        "width" => "100",
        "width_type" => "%",
        "height" => "300",
        "height_type" => "px",
        "lat" => "",
        "lng" => "",
        "map_name" => "",
        "styles" => "",
        "custom_map_style" => "default",
        "zoom" => 17,
        "disable_auto_zoom" => "true",
        "dragging_mobile" => "true",
        "dragging_desktop" => "true",
        "traffic_layer" => "false",
        "transit_layer" => "false",
        "bicycling_layer" => "false",
        "marker_animation" => "",
        "disable_map_controls" => "false",
        "marker_clustering" => "no"
    ), $atts));

    $map_types_concat = $add_marker_clustering = $map_types_concat_separator = '';

    if($marker_clustering == "yes")
    {
        $images_path = wwp_vc_gmaps_images_path .'m';

        $add_marker_clustering = '
        var mcOptions = { 
            imagePath: "'.$images_path.'"
        };
        var mc = new MarkerClusterer(map, markers_cluster, mcOptions);';
    }

    if($map_type_control_options != '')
    {
        $map_types = explode(",", $map_type_control_options);

        foreach($map_types as $map_type)
        {
            $map_types_concat .= $map_types_concat_separator.'google.maps.MapTypeId.'.$map_type;
            $map_types_concat_separator = ',';
        }
    }
    else
    {
        $map_types_concat = 'google.maps.MapTypeId.ROADMAP';
    }

    if($map_name == "" && ($styles != "" || $custom_map_style != "default") )
    {
        $map_name = 'Custom Map';
    }

    if($map_name != '')
    {
        $map_types_concat = $map_types_concat.', "map_style"';
    }

    $map_name_show = 'mapTypeIds: ['.$map_types_concat.'],';

    if($transit_layer == "true")
    {
        $add_transit_layer = 'var transitLayer = new google.maps.TransitLayer();transitLayer.setMap(map);';
    }

    if($traffic_layer == "true")
    {
        $add_traffic_layer = 'var trafficlayer = new google.maps.TrafficLayer();trafficlayer.setMap(map);';
    }

    if($bicycling_layer == "true")
    {
        $add_bicycling_layer = 'var bicyclinglayer = new google.maps.BicyclingLayer();bicyclinglayer.setMap(map);';
    }

    $id = "map_".uniqid();

    if($height != '')
    {
        if($height_type == '%')
        {
            $height_type = 'vh';
        }

        $add_map_height = 'height: '. $height . $height_type.'; ';
    }

    if($width != '')
    {
        $add_map_width = 'width: '. $width . $width_type.'; ';

    }

    if(wp_is_mobile())
    {
        $dragging = $dragging_mobile;
    }
    else
    {
        $dragging = $dragging_desktop;
    }

    if($dragging_control == "true")
    {
        wp_enqueue_style( 'font-awesome' );
        $add_dragging_control = 'map.controls[google.maps.ControlPosition.'.$dragging_control_position.'].push(addLockBtn());';
    }

    if($styles != '')
    {
        $add_map_styling = '
                var styledMap = new google.maps.StyledMapType('.rawurldecode(base64_decode(strip_tags($styles))).', {name: "'.$map_name.'"});
                map.mapTypes.set("map_style", styledMap);
                map.setMapTypeId("map_style");
            ';
    }
    else
    {
        $add_map_styling = '
                var styledMap = new google.maps.StyledMapType(custom_map_styles["'.$custom_map_style.'"], {name: "'.$map_name.'"});
                map.mapTypes.set("map_style", styledMap);
                map.setMapTypeId("map_style");
            ';
    }

    $markers = do_shortcode( $content );
    $all_locations = $add_places = $location_separator = '';
    foreach($WWP_GMAPS_SHORTCODE['markers'] as $location)
    {
        $pin_path = $pin_width = $pin_height = '';
        if($location['icon_url'] != '')
        {
            if($location['marker_type'] == 'custom')
            {
                $pin_icon = wp_get_attachment_image_src($location['icon_url'], 'full');
                if($pin_icon)
                {
                    $pin_path = $pin_icon[0];
                    $pin_width = $pin_icon[1];
                    $pin_height = $pin_icon[2];
                }
            }
            if($location['marker_type'] == 'predefined')
            {
                $pin_width = 45;
                $pin_height = 60;

                $pin_path = $location['icon_url'];
                $pin_info = @getimagesize($pin_path);
                if($pin_info)
                {
                    $pin_width = $pin_info[0];
                    $pin_height = $pin_info[1];
                }
            }
        }

        $all_locations .= $location_separator.'["'.$location['animation'].'", '.$location['lat'].', '.$location['lng'].', 1, "'.$location['description'].'", "", "'.$location['icon_url'].'", "'.$pin_path.'", '.$pin_width.', '.$pin_height.']';
        $location_separator = ',';
    }

    $add_places = 'var places=['.$all_locations.'];';
    $add_disable_auto_zoom = '';
    if($disable_auto_zoom == "false")
    {
        $add_disable_auto_zoom = '
        var listener = google.maps.event.addListener(map, "idle", function() { 
                          if (map.getZoom() > '.$zoom.') map.setZoom('.$zoom.'); 
                          google.maps.event.removeListener(listener); 
                        });
        ';
    }

    if($disable_map_controls == "true")
    {
        $map_type_control = "false";
        $zoom_control = "false";
        $fullscreen_control = "false";
        $streetview_control = "false";
        $add_dragging_control = "";
    }
    $output = '
                <script type="text/javascript">
                    var markers_cluster = [];
                    
                    function initialize_vc_gmap()
                    {
                        var custom_map_styles = 
                        {
                            apple_maps: [{"featureType":"landscape.man_made","elementType":"geometry","stylers":[{"color":"#f7f1df"}]},{"featureType":"landscape.natural","elementType":"geometry","stylers":[{"color":"#d0e3b4"}]},{"featureType":"landscape.natural.terrain","elementType":"geometry","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi.business","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi.medical","elementType":"geometry","stylers":[{"color":"#fbd3da"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#bde6ab"}]},{"featureType":"road","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffe15f"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#efd151"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"road.local","elementType":"geometry.fill","stylers":[{"color":"black"}]},{"featureType":"transit.station.airport","elementType":"geometry.fill","stylers":[{"color":"#cfb2db"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#a2daf2"}]}],
                            light_gray: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}],
                            dark: [{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"landscape","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"landscape","elementType":"labels.icon","stylers":[{"saturation":"-100"},{"lightness":"-54"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"on"},{"lightness":"0"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},{"featureType":"poi","elementType":"labels.icon","stylers":[{"saturation":"-89"},{"lightness":"-55"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"transit.station","elementType":"labels.icon","stylers":[{"visibility":"on"},{"saturation":"-100"},{"lightness":"-51"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}],
                            neutral_blue: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"#193341"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#2c5a71"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#29768a"},{"lightness":-37}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#406d80"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#406d80"}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#3e606f"},{"weight":2},{"gamma":0.84}]},{"elementType":"labels.text.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"weight":0.6},{"color":"#1a3541"}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#2c5a71"}]}],
                            orange_ocean: [{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#444444"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2f2f2"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#edc200"}]},{"featureType":"road.highway","elementType":"labels.text.fill","stylers":[{"color":"#000000"}]},{"featureType":"road.highway","elementType":"labels.text.stroke","stylers":[{"color":"#ffffff"},{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#f5a301"},{"visibility":"on"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#000000"}]},{"featureType":"water","elementType":"labels.text.stroke","stylers":[{"visibility":"off"}]}],
                            magenta: [{"featureType":"all","elementType":"geometry.stroke","stylers":[{"visibility":"simplified"}]},{"featureType":"administrative","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"labels","stylers":[{"visibility":"simplified"},{"color":"#a31645"}]},{"featureType":"landscape","elementType":"all","stylers":[{"weight":"3.79"},{"visibility":"on"},{"color":"#ffecf0"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"landscape","elementType":"geometry.stroke","stylers":[{"visibility":"on"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"simplified"},{"color":"#a31645"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"saturation":"0"},{"lightness":"0"},{"visibility":"off"}]},{"featureType":"poi","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"poi.business","elementType":"all","stylers":[{"visibility":"simplified"},{"color":"#d89ca8"}]},{"featureType":"poi.business","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"poi.business","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"saturation":"0"}]},{"featureType":"poi.business","elementType":"labels","stylers":[{"color":"#a31645"}]},{"featureType":"poi.business","elementType":"labels.icon","stylers":[{"visibility":"simplified"},{"lightness":"84"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#d89ca8"},{"visibility":"on"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#fedce3"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"off"}]}],
                            flat_map: [{"featureType":"all","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"all","stylers":[{"visibility":"on"},{"color":"#f3f4f4"}]},{"featureType":"landscape.man_made","elementType":"geometry","stylers":[{"weight":0.9},{"visibility":"off"}]},{"featureType":"poi.park","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#83cead"}]},{"featureType":"road","elementType":"all","stylers":[{"visibility":"on"},{"color":"#ffffff"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"on"},{"color":"#fee379"}]},{"featureType":"road.arterial","elementType":"all","stylers":[{"visibility":"on"},{"color":"#fee379"}]},{"featureType":"water","elementType":"all","stylers":[{"visibility":"on"},{"color":"#7fc8ed"}]}],
                            winter: [{"stylers":[{"hue":"#007fff"},{"saturation":89}]},{"featureType":"water","stylers":[{"color":"#ffffff"}]},{"featureType":"administrative.country","elementType":"labels","stylers":[{"visibility":"off"}]}],
                            
                        };
                        
                        var mapOptions =
                        {
                            scrollwheel: false,
                            draggable: '.$dragging.',
                            fullscreenControl: '.$fullscreen_control.',
                            streetViewControl: '.$streetview_control.',
                            streetViewControlOptions: {
                                position: google.maps.ControlPosition.'.$streetview_control_position.'
                            },
                            zoomControl: '.$zoom_control.',
                            zoomControlOptions: {
                                position: google.maps.ControlPosition.'.$zoom_control_position.'
                            },
                            mapTypeControl: '.$map_type_control.',
                            mapTypeControlOptions: {
                                '.$map_name_show.'
                                position: google.maps.ControlPosition.'.$map_type_control_position.'
                            }
                        }

                        var map = new google.maps.Map(document.getElementById("'.$id.'"), mapOptions);
                        '.$add_transit_layer.'
                        '.$add_bicycling_layer.'
                        '.$add_traffic_layer.'
                        '.$add_map_styling.'
                        
                        '.$add_places.'

                        setMarkers(map, places);

                        '.$add_marker_clustering.'

                        infowindow = new google.maps.InfoWindow(
                        {
                            content: "loading..."
                        });
                        
                        '.$add_disable_auto_zoom.'
                        
                        '.$add_dragging_control.'

                        function addLockBtn()
                        {
                            var draggable_icon_class = "";

                            if (map.get("draggable") == false)
                            {
                                draggable_icon_class = "fa fa-lock";
                            }
                            else
                            {
                                draggable_icon_class = "fa fa-unlock";
                            }
                                
                            var lock_btn = jQuery(\'<div class="lock-button-gmaps"><i class="fa \'+draggable_icon_class+\'"></i></div>\');
                            
                            lock_btn.bind("click", function()
                            {
                                if (map.get("draggable")) 
                                {
                                    map.set("draggable", false);
                                    jQuery(".lock-button-gmaps i").removeClass("fa-unlock");
                                    jQuery(".lock-button-gmaps i").addClass("fa-lock");
                                } 
                                else 
                                {
                                    map.set("draggable", true);
                                    jQuery(".lock-button-gmaps i").removeClass("fa-lock");
                                    jQuery(".lock-button-gmaps i").addClass("fa-unlock");
                                }
                            });
                            
                            return lock_btn[0];
                        }
                    }
                    
                    function setMarkers(map, locations)
                    {
                        var bounds = new google.maps.LatLngBounds();

                        for (var i = 0; i < locations.length; i++)
                        {
                            var place = locations[i],
                                image = "";
                                
                            if(place[6])
                            {
                                image = {
                                    url: place[7],
                                    size: new google.maps.Size(place[8], place[9]),
                                    origin: new google.maps.Point(0,0),
                                    anchor: new google.maps.Point(place[8]/2, place[9])
                                };
                            }
                            var myLatLng = new google.maps.LatLng(place[1], place[2]);
                            
                            var marker = new google.maps.Marker(
                            {
                                position: myLatLng,
                                icon: image,
                                map: map,
                                zIndex: place[3],
                                html: decodeURIComponent(place[4])
                            });
                            
                            markers_cluster.push(marker);
                            
                            if(place[0] == "DROP")
                            {
                                    marker.setAnimation(google.maps.Animation.DROP);
                            }
                            else
                            {
                                    marker.setAnimation(google.maps.Animation.BOUNCE);

                            }
                            bounds.extend(marker.position);
                            
                          
                            google.maps.event.addListener(marker, "click", function ()
                            {
                                if(decodeURIComponent(this.html) != "")
                                {
                                    infowindow.setContent(decodeURIComponent(this.html));
                                    infowindow.open(map, this);
                                }
                            });
                        }
                        
                        map.fitBounds(bounds);
                        
                    }
                                        
                    google.maps.event.addDomListener(window, "load", initialize_vc_gmap);
                </script>
            ';

    $output .= '<div id="'.$id.'" class="wpb_content_element" style="'.$add_map_height.$add_map_width.'"><div class="map_lock"></div></div>';

    return $output;
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_wwp_vc_gmaps extends WPBakeryShortCodesContainer {
    }
}

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_wwp_vc_gmaps_marker extends WPBakeryShortCode {
    }
}