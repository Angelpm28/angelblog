jQuery(document).ready(function()
{
    if (typeof google === "object" && typeof google.maps === "object")
    {
        
    }
    else
    {
        var script = document.createElement("script");
        script.type = "text/javascript";
        script.src = "http://maps.google.com/maps/api/js?sensor=false&callback=handleApiReady";
        document.body.appendChild(script);
    }
});
